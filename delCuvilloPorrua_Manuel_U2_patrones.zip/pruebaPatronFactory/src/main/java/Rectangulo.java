public class Rectangulo extends Figura{

    public Rectangulo(String color) {
        super(color);
    }

    @Override
    /*public Figura dibujarFigura() {
        return new Rectangulo("Azul");
    }
     */
    public String dibujarFigura() {
        return "Rectangulo";
    }
}
