public class Main {
    public static void main(String[] args) {
        FiguraFactory seleccionar = new FiguraFactory();

        Figura circulo = seleccionar.getCreateFiguras("Circulo");
        Figura cuadrado = seleccionar.getCreateFiguras("Cuadrado");
        Figura rectangulo = seleccionar.getCreateFiguras("Rectangulo");
        Figura triangulo = seleccionar.getCreateFiguras("Triangulo");

        Circulo circulo1 = new Circulo("Azul");
        Cuadrado cuadrado1 = new Cuadrado("Amarillo");
        Rectangulo rectangulo1 = new Rectangulo("Verde");
        Triangulo triangulo1 = new Triangulo("Rojo");

        System.out.println("");
        System.out.println("Figura: " + circulo.dibujarFigura() + " " + circulo1.getColor());
        System.out.println("Figura: " + cuadrado.dibujarFigura() + " " + cuadrado1.getColor());
        System.out.println("Figura: " + rectangulo.dibujarFigura() + " " + rectangulo1.getColor());
        System.out.println("Figura: " + triangulo.dibujarFigura() + " " + triangulo1.getColor());

    }
}