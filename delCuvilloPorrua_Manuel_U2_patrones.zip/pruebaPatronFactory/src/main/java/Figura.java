public abstract class Figura {

    private String color;

    public Figura(String color) {
        this.color = color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    //public abstract Figura dibujarFigura();
    public abstract String dibujarFigura();
}
