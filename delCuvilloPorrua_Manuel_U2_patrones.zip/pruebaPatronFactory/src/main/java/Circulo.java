public class Circulo extends Figura {

    public Circulo(String color) {
        super(color);
    }
    @Override
    /*
    public Figura dibujarFigura() {
        return new Circulo("Rojo");
    }
     */
    public String dibujarFigura() {
        return "Circulo";
    }

}
