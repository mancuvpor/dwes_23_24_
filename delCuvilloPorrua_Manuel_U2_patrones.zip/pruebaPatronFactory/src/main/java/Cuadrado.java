public class Cuadrado extends Figura {

    public Cuadrado(String color) {
        super(color);
    }

    @Override
    /*public Figura dibujarFigura() {
        return new Cuadrado("Amarillo");
    }
     */
    public String dibujarFigura() {
        return "Cuadrado";
    }
}
