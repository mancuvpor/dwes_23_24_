public class FiguraFactory extends FactoryConstructorFiguras {

    public String color = "";

    @Override
    public Figura getCreateFiguras(String tipo) {
        if (tipo.equals("Circulo")) {
            return new Circulo(color);
        } else if (tipo.equals("Cuadrado")) {
            return new Cuadrado(color);
        } else if (tipo.equals("Rectangulo")) {
            return new Rectangulo(color);
        } else if (tipo.equals("Triangulo")) {
            return new Triangulo(color);
        }
        return null;
    }
}
