public class Triangulo extends Figura{

    public Triangulo(String color) {
        super(color);
    }

    @Override
    /*public Figura dibujarFigura() {
        return new Triangulo("Verde");
    }
     */
    public String dibujarFigura() {
        return "Triangulo";
    }
}
