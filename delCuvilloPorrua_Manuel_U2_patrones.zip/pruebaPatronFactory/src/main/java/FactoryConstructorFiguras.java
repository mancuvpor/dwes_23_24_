public abstract class FactoryConstructorFiguras {

    public abstract Figura getCreateFiguras(String tipo);

}
