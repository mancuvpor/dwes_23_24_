public class Main {

    public static void main(String[] args) {
        Presidente presidente1 = Presidente.getInstance("Barack ","Obama ","2009");



    }
}
