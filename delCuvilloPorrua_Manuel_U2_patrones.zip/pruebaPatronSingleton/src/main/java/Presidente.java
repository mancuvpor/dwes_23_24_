public class Presidente {

    private static Presidente instance = null;
    private String nombre;
    private String apellidos;
    private String anno_eleccion;

    private Presidente(String nombre, String apellidos, String anno_eleccion) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.anno_eleccion = anno_eleccion;
        System.out.println("Presidente: " + this.nombre + this.apellidos + this.anno_eleccion);

    }

    public static Presidente getInstance(String nombre, String apellidos, String anno_eleccion) {
        if (Presidente.instance == null) {
            nombre = nombre;
            apellidos = apellidos;
            anno_eleccion = anno_eleccion;
            System.out.println("Presidente: " + nombre + apellidos + anno_eleccion);
            //return instance;
        }else {
            System.out.println("No se puede crear ");
        }
        return Presidente.instance;
    }
        public static void setInstance (Presidente instance){
            Presidente.instance = instance;
        }

        public String getNombre () {
            return nombre;
        }

        public void setNombre (String nombre){
            this.nombre = nombre;
        }

        public String getApellidos () {
            return apellidos;
        }

        public void setApellidos (String apellidos){
            this.apellidos = apellidos;
        }

        public String getAnno_eleccion () {
            return anno_eleccion;
        }

        public void setAnno_eleccion (String anno_eleccion){
            this.anno_eleccion = anno_eleccion;
        }

        // Metodo para obtener instancia:
        public static Presidente obtenerInstacia (Presidente presidente){
            if (Presidente.instance == null) {
                Presidente.instance = new Presidente(presidente.nombre, presidente.apellidos, presidente.anno_eleccion);
            } else {
                System.out.println("No se puede crear " + presidente);
            }
            return Presidente.instance;
        }
    }
